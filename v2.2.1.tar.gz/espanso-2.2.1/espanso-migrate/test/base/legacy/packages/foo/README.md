---
package_name: "foo"
package_title: "Foo"
package_desc: "Foo package"
package_version: "0.1.0"
package_author: "Federico Terzi"
package_repo: "https://github.com/federico-terzi/espanso-hub-core"
---
Test package