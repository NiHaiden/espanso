This module is used to detect keyboard and mouse input using EVDEV layer, which is necessary on Wayland.
The module started as a port of this xkbcommon example
https://github.com/xkbcommon/libxkbcommon/blob/master/tools/interactive-evdev.c