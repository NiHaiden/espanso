This is a fallback injection module that relies on the awesome xdotool project: 
https://github.com/jordansissel/xdotool