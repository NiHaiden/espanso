---
name: Feature request
about: Suggest an idea to make Espanso better
title: ''
labels: ''
assignees: ''

---

Feature requests have been moved to discussions, please open it there :)

https://github.com/espanso/espanso/discussions/categories/feature-requests-and-ideas